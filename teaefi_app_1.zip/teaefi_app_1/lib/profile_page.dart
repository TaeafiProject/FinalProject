import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart' show Uint8List, kIsWeb;
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'register_page.dart';
import 'update_profile_page.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final User? _currentUser = FirebaseAuth.instance.currentUser;
  Map<String, dynamic> _userData = {
    'full_name': '',
    'email': '',
    'gender': '',
    'id_number': '',
    'date_of_birth': '',
    'phone': '',
    'weight': '',
    'height': '',
    'blood_type': '',
    'insurance_provider': '',
    'place_of_birth': '',
    'profile_picture': '',
  };
  String? _placeholderUrl;
  File? _imageFile;

  @override
  void initState() {
    super.initState();
    fetchUserData();
    fetchPlaceholderImage();
  }

  Future<void> fetchUserData() async {
    if (_currentUser != null) {
      DocumentSnapshot userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(_currentUser!.uid)
          .get();

      if (userDoc.exists) {
        setState(() {
          _userData = userDoc.data() as Map<String, dynamic>;
        });
      }
    }
  }

  Future<void> fetchPlaceholderImage() async {
    try {
      final ref = FirebaseStorage.instance.ref().child('placeholder.jpg');
      final url = await ref.getDownloadURL();
      setState(() {
        _placeholderUrl = url;
      });
    } catch (e) {
      print('Error fetching placeholder image: $e');
    }
  }

  Future<void> _logout() async {
    await FirebaseAuth.instance.signOut();
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (context) => RegisterPage()),
      (Route<dynamic> route) => false,
    );
  }

  Future<void> _pickImage() async {
    final pickedFile = await ImagePicker().getImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      if (kIsWeb) {
        // Handle file upload for web
        await _uploadImageToStorage(pickedFile.readAsBytes(), isWeb: true);
      } else {
        setState(() {
          _imageFile = File(pickedFile.path);
        });
        await _uploadImageToStorage(File(pickedFile.path).readAsBytes());
      }
    }
  }

  Future<void> _uploadImageToStorage(Future<Uint8List> imageBytesFuture, {bool isWeb = false}) async {
    try {
      final imageBytes = await imageBytesFuture;
      final ref = FirebaseStorage.instance
          .ref()
          .child('profile_pictures')
          .child('${_currentUser!.uid}.jpg');
      if (isWeb) {
        await ref.putData(imageBytes);
      } else {
        await ref.putFile(File(imageBytes as String));
      }
      final url = await ref.getDownloadURL();
      await FirebaseFirestore.instance
          .collection('users')
          .doc(_currentUser?.uid)
          .update({'profile_picture': url});
      setState(() {
        _userData['profile_picture'] = url;
      });
    } catch (e) {
      print('Error uploading image: $e');
    }
  }

  Future<void> _deleteImage() async {
    setState(() {
      _imageFile = null;
      _userData['profile_picture'] = '';
    });
    await FirebaseFirestore.instance
        .collection('users')
        .doc(_currentUser?.uid)
        .update({'profile_picture': ''});
  }

  void _showImageOptions() {
    showModalBottomSheet(
      context: context,
      builder: (context) => Wrap(
        children: [
          ListTile(
            leading: const Icon(Icons.photo_camera),
            title: const Text('Change Profile Picture'),
            onTap: () {
              Navigator.pop(context);
              _pickImage();
            },
          ),
          ListTile(
            leading: const Icon(Icons.delete),
            title: const Text('Delete Profile Picture'),
            onTap: () {
              Navigator.pop(context);
              _deleteImage();
            },
          ),
        ],
      ),
    );
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Error'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false, // Remove back button
        title: const Text('INFORMATION'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: _logout,
          ),
        ],
      ),
      body: _userData.isEmpty || _placeholderUrl == null
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  GestureDetector(
                    onTap: _showImageOptions,
                    child: CircleAvatar(
                      radius: 50,
                      backgroundColor: Colors.blue,
                      backgroundImage: _imageFile != null
                          ? FileImage(_imageFile!)
                          : (_userData['profile_picture'] != null && _userData['profile_picture'] != ''
                              ? NetworkImage(_userData['profile_picture'])
                              : NetworkImage(_placeholderUrl!)) as ImageProvider,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    _userData['full_name'] ?? 'N/A',
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.blue,
                    ),
                  ),
                  const SizedBox(height: 16),
                  ProfileInfoRow(label: 'Username', value: _userData['full_name'] ?? 'N/A'),
                  ProfileInfoRow(label: 'Email', value: _userData['email'] ?? 'N/A'),
                  ProfileInfoRow(label: 'ID Number', value: _userData['id_number'] ?? 'N/A'),
                  ProfileInfoRow(label: 'Gender', value: _userData['gender'] ?? 'N/A'),
                  ProfileInfoRow(label: 'Date of Birth', value: _userData['date_of_birth'] ?? 'N/A'),
                  ProfileInfoRow(label: 'Phone', value: _userData['phone'] ?? 'N/A'),
                  ProfileInfoRow(label: 'Weight', value: _userData['weight'] ?? 'N/A'),
                  ProfileInfoRow(label: 'Height', value: _userData['height'] ?? 'N/A'),
                  ProfileInfoRow(label: 'Blood Type', value: _userData['blood_type'] ?? 'N/A'),
                  ProfileInfoRow(label: 'Insurance Provider', value: _userData['insurance_provider'] ?? 'N/A'),
                  ProfileInfoRow(label: 'Place of Birth', value: _userData['place_of_birth'] ?? 'N/A'),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () async {
                      await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => UpdateProfilePage(
                            fullName: _userData['full_name'] ?? '',
                            email: _userData['email'] ?? '',
                            gender: _userData['gender'] ?? '',
                            idNumber: _userData['id_number'] ?? '',
                            dateOfBirth: _userData['date_of_birth'] ?? '',
                            phone: _userData['phone'] ?? '',
                            weight: _userData['weight'] ?? '',
                            height: _userData['height'] ?? '',
                            bloodType: _userData['blood_type'] ?? '',
                            insuranceProvider: _userData['insurance_provider'] ?? '',
                            placeOfBirth: _userData['place_of_birth'] ?? '',
                          ),
                        ),
                      );
                      fetchUserData(); // Refresh the profile page data after updating
                    },
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 40),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                    child: const Text(
                      'Update Information',
                      style: TextStyle(fontSize: 18),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}

class ProfileInfoRow extends StatelessWidget {
  final String label;
  final String value;

  const ProfileInfoRow({super.key, 
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: Colors.blue,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              fontSize: 16,
            ),
          ),
        ],
      ),
    );
  }
}
