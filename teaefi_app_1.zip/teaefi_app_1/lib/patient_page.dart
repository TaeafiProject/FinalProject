import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';

import 'appointment_page.dart';
import 'profile_page.dart';

class PatientPage extends StatefulWidget {
  final User? user;

  PatientPage({super.key, this.user});

  @override
  _PatientPageState createState() => _PatientPageState();
}

class _PatientPageState extends State<PatientPage> {
  String fullName = '';
  List<Map<String, dynamic>> doctors = [];
  String? placeholderImageUrl;
  int _selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    fetchUserDetails();
    fetchDoctorsFromRealtimeDatabase();
    fetchPlaceholderImage();
  }

  Future<void> fetchUserDetails() async {
    if (widget.user != null) {
      DocumentSnapshot userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(widget.user!.uid)
          .get();

      if (userDoc.exists) {
        setState(() {
          fullName = userDoc['full_name'] ?? '';
        });
      }
    }
  }

  Future<void> fetchDoctorsFromRealtimeDatabase() async {
    final DatabaseReference ref = FirebaseDatabase.instance.ref().child('users');
    DatabaseEvent event = await ref.once();

    if (event.snapshot.value != null) {
      Map<dynamic, dynamic> users = event.snapshot.value as Map<dynamic, dynamic>;
      setState(() {
        doctors = users.entries.map((entry) {
          return {
            'id': entry.key,
            'name': entry.value['name'] ?? 'Unknown',
            'rating': entry.value['rating'] ?? 0,
            'price': entry.value['price'] ?? 0,
            'imageUrl': entry.value['imageUrl'],
          };
        }).toList();
      });
    }
  }

  Future<void> fetchPlaceholderImage() async {
    try {
      final ref = FirebaseStorage.instance.ref().child('profile_pictures/placeholder.jpg');
      final url = await ref.getDownloadURL();
      setState(() {
        placeholderImageUrl = url;
      });
    } catch (e) {
      print('Error fetching placeholder image: $e');
      setState(() {
        placeholderImageUrl = 'assets/images/placeholder.jpg'; // Local asset as fallback
      });
    }
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    List<Widget> _pages = <Widget>[
      HomeContent(
        fullName: fullName,
        doctors: doctors,
        placeholderImageUrl: placeholderImageUrl,
      ),
      Container(), // Placeholder for Messages page
      PatientRecordPage(),
      ProfilePage(),
    ];

    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false, // Remove back button
        title: const Text('HOME'),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications),
            onPressed: () {},
          ),
        ],
      ),
      body: IndexedStack(
        index: _selectedIndex,
        children: _pages,
      ),
      bottomNavigationBar: BottomNavigationBar(
        selectedItemColor: Colors.blue, // Set the selected icon color
        unselectedItemColor: Colors.grey, // Set the unselected icon color
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.message),
            label: 'Messages',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.medical_services),
            label: 'Records',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
    );
  }

  Widget _buildDoctorImage(String? imageUrl) {
    if (imageUrl == null || imageUrl.isEmpty) {
      return Image.asset(
        placeholderImageUrl!,
        width: 80,
        height: 80,
      );
    } else {
      return Image.network(
        imageUrl,
        width: 80,
        height: 80,
        errorBuilder: (context, error, stackTrace) {
          return Image.asset(
            'assets/images/placeholder.jpg',
            width: 80,
            height: 80,
          );
        },
      );
    }
  }
}

class HomeContent extends StatelessWidget {
  final String fullName;
  final List<Map<String, dynamic>> doctors;
  final String? placeholderImageUrl;

  const HomeContent({
    super.key,
    required this.fullName,
    required this.doctors,
    required this.placeholderImageUrl,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Good Morning, $fullName',
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.lightBlue, // Set text color to light blue
            ),
          ),
          const SizedBox(height: 20),
          SizedBox(
            height: 150,
            child: PageView.builder(
              itemCount: doctors.length,
              itemBuilder: (context, index) {
                final doctor = doctors[index];
                return Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      children: [
                        _buildDoctorImage(doctor['imageUrl']),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Text(
                                'Recommended Doctors',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                '${doctor['name']}\nStart from \$${doctor['price']} per Hour',
                                style: const TextStyle(color: Colors.white),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'Best Doctors Online',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.blue, // Set text color to blue
            ),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: ListView.builder(
              itemCount: doctors.length,
              itemBuilder: (context, index) {
                final doctor = doctors[index];
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: DoctorCard(
                    doctor: doctor,
                    placeholderImageUrl: placeholderImageUrl,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => AppointmentPage(doctorId: doctor['id']),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDoctorImage(String? imageUrl) {
    if (imageUrl == null || imageUrl.isEmpty) {
      return Image.asset(
        placeholderImageUrl!,
        width: 80,
        height: 80,
      );
    } else {
      return Image.network(
        imageUrl,
        width: 80,
        height: 80,
        errorBuilder: (context, error, stackTrace) {
          return Image.asset(
            'assets/images/placeholder.jpg',
            width: 80,
            height: 80,
          );
        },
      );
    }
  }
}

class DoctorCard extends StatelessWidget {
  final Map<String, dynamic> doctor;
  final String? placeholderImageUrl;
  final VoidCallback onTap;

  const DoctorCard({
    super.key,
    required this.doctor,
    required this.placeholderImageUrl,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: onTap,
        child: SizedBox(
          width: MediaQuery.of(context).size.width * 0.9, // Adjust width to fit within the screen
          child: ListTile(
            leading: _buildDoctorImage(doctor['imageUrl']),
            title: Text(doctor['name']),
            subtitle: Text('\$${doctor['price']} Per Hour'),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.star, color: Colors.yellow),
                Text(doctor['rating'].toString()),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDoctorImage(String? imageUrl) {
    if (imageUrl == null || imageUrl.isEmpty) {
      return Image.asset(
        'assets/images/placeholder.jpg',
        width: 50,
        height: 50,
      );
    } else {
      return Image.network(
        imageUrl,
        width: 50,
        height: 50,
        errorBuilder: (context, error, stackTrace) {
          return Image.asset(
            'assets/images/placeholder.jpg',
            width: 50,
            height: 50,
          );
        },
      );
    }
  }
}

class PatientRecordPage extends StatelessWidget {
  const PatientRecordPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false, // Remove back button
        title: const Text('PATIENT MEDICAL RECORD'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: CircleAvatar(
                  radius: 50,
                  backgroundImage: AssetImage('assets/images/placeholder.jpg'), // Placeholder image
                ),
              ),
              const SizedBox(height: 20),
              const Center(
                child: Text(
                  'Full name',
                  style: TextStyle(fontSize: 18, color: Colors.blue),
                ),
              ),
              const SizedBox(height: 10),
              const Center(
                child: Text(
                  'birthdate',
                  style: TextStyle(fontSize: 18, color: Colors.blue),
                ),
              ),
              const SizedBox(height: 10),
              const Center(
                child: Text(
                  'ID number',
                  style: TextStyle(fontSize: 18, color: Colors.blue),
                ),
              ),
              const SizedBox(height: 10),
              const Center(
                child: Text(
                  'Blood type',
                  style: TextStyle(fontSize: 18, color: Colors.blue),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'List of RECORDS :',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              const Text(
                'chronic illnesses',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.blue),
              ),
              const Text('1. Asthma'),
              const Text('2. ALS'),
              const Text('3. Syndrome'),
              const SizedBox(height: 20),
              const Text(
                'Recent Visits and Treatments',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.blue),
              ),
              const Text('Visit Date: [Date of Visit]'),
              const Text('Visited Doctor: [Doctor\'s Name]'),
              const Text('Clinic/Hospital: [Name of the Clinic or Hospital]'),
              const Text('Diagnosis: [Diagnosis]'),
              const Text('Treatments Provided'),
              const Text('Treatment 1: [Description of Treatment 1]'),
              const SizedBox(height: 20),
              const Text(
                'Follow-up Recommendations',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.blue),
              ),
              const Text('Next Appointment: [Scheduled Date and Time]'),
              const Text('Recommended Tests: [List of suggested tests or procedures]'),
              const Text('Additional Notes: [Any additional recommendations or notes from the doctor]'),
            ],
          ),
        ),
      ),
    );
  }
}
