import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class PatientRecordPage extends StatefulWidget {
  const PatientRecordPage({super.key});

  @override
  _PatientRecordPageState createState() => _PatientRecordPageState();
}

class _PatientRecordPageState extends State<PatientRecordPage> {
  final User? _currentUser = FirebaseAuth.instance.currentUser;
  final TextEditingController _allergyController = TextEditingController();
  final TextEditingController _chronicIllnessController = TextEditingController();
  final TextEditingController _surgeryController = TextEditingController();
  List<String> _allergies = [];
  List<String> _chronicIllnesses = [];
  List<String> _pastSurgeries = [];

  @override
  void initState() {
    super.initState();
    fetchMedicalRecord();
  }

  Future<void> fetchMedicalRecord() async {
    if (_currentUser != null) {
      DocumentSnapshot medicalRecordDoc = await FirebaseFirestore.instance
          .collection('MedicalRecord')
          .doc(_currentUser!.uid)
          .get();

      if (medicalRecordDoc.exists) {
        setState(() {
          _allergies = List<String>.from(medicalRecordDoc['allergies'] ?? []);
          _chronicIllnesses = List<String>.from(medicalRecordDoc['chronic_illnesses'] ?? []);
          _pastSurgeries = List<String>.from(medicalRecordDoc['past_surgeries'] ?? []);
        });
      }
    }
  }

  Future<void> updateMedicalRecord() async {
    if (_currentUser != null) {
      await FirebaseFirestore.instance.collection('MedicalRecord').doc(_currentUser!.uid).set({
        'user_id': _currentUser!.uid,
        'allergies': _allergies,
        'chronic_illnesses': _chronicIllnesses,
        'past_surgeries': _pastSurgeries,
      });
    }
  }

  void _addItem(String type) {
    switch (type) {
      case 'allergy':
        setState(() {
          _allergies.add(_allergyController.text);
          _allergyController.clear();
        });
        break;
      case 'chronic_illness':
        setState(() {
          _chronicIllnesses.add(_chronicIllnessController.text);
          _chronicIllnessController.clear();
        });
        break;
      case 'surgery':
        setState(() {
          _pastSurgeries.add(_surgeryController.text);
          _surgeryController.clear();
        });
        break;
    }
    updateMedicalRecord();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false, // Remove back button
        title: const Text('PATIENT MEDICAL RECORD'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'List of RECORDS :',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              const Text(
                'Allergies',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.blue),
              ),
              ..._allergies.map((allergy) => Text(allergy)).toList(),
              TextField(
                controller: _allergyController,
                decoration: InputDecoration(
                  labelText: 'Add Allergy',
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.add),
                    onPressed: () => _addItem('allergy'),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'Chronic Illnesses',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.blue),
              ),
              ..._chronicIllnesses.map((illness) => Text(illness)).toList(),
              TextField(
                controller: _chronicIllnessController,
                decoration: InputDecoration(
                  labelText: 'Add Chronic Illness',
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.add),
                    onPressed: () => _addItem('chronic_illness'),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'Past Surgeries',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.blue),
              ),
              ..._pastSurgeries.map((surgery) => Text(surgery)).toList(),
              TextField(
                controller: _surgeryController,
                decoration: InputDecoration(
                  labelText: 'Add Surgery',
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.add),
                    onPressed: () => _addItem('surgery'),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'Recent Visits and Treatments',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.blue),
              ),
              const Text('Visit Date: [Date of Visit]'),
              const Text('Visited Doctor: [Doctor\'s Name]'),
              const Text('Clinic/Hospital: [Name of the Clinic or Hospital]'),
              const Text('Diagnosis: [Diagnosis]'),
              const Text('Treatments Provided'),
              const Text('Treatment 1: [Description of Treatment 1]'),
              const SizedBox(height: 20),
              const Text(
                'Follow-up Recommendations',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.blue),
              ),
              const Text('Next Appointment: [Scheduled Date and Time]'),
              const Text('Recommended Tests: [List of suggested tests or procedures]'),
              const Text('Additional Notes: [Any additional recommendations or notes from the doctor]'),
            ],
          ),
        ),
      ),
    );
  }
}
