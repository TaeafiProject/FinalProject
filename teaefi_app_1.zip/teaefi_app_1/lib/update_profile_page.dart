import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class UpdateProfilePage extends StatefulWidget {
  final String fullName;
  final String email;
  final String gender;
  final String idNumber;
  final String dateOfBirth;
  final String phone;
  final String weight;
  final String height;
  final String bloodType;
  final String insuranceProvider;
  final String placeOfBirth;

  const UpdateProfilePage({
    super.key,
    required this.fullName,
    required this.email,
    required this.gender,
    required this.idNumber,
    required this.dateOfBirth,
    required this.phone,
    required this.weight,
    required this.height,
    required this.bloodType,
    required this.insuranceProvider,
    required this.placeOfBirth,
  });

  @override
  _UpdateProfilePageState createState() => _UpdateProfilePageState();
}

class _UpdateProfilePageState extends State<UpdateProfilePage> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _phoneController;
  late TextEditingController _weightController;
  late TextEditingController _heightController;
  late TextEditingController _bloodTypeController;
  late TextEditingController _insuranceProviderController;
  late TextEditingController _placeOfBirthController;

  String _selectedCountryCode = '+962';
  String _selectedBloodType = 'O+';

  @override
  void initState() {
    super.initState();
    _phoneController = TextEditingController(text: widget.phone);
    _weightController = TextEditingController(text: widget.weight);
    _heightController = TextEditingController(text: widget.height);
    _bloodTypeController = TextEditingController(text: widget.bloodType);
    _insuranceProviderController = TextEditingController(text: widget.insuranceProvider);
    _placeOfBirthController = TextEditingController(text: widget.placeOfBirth);

    if (widget.bloodType.isNotEmpty) {
      _selectedBloodType = widget.bloodType;
    }

    // If the phone field includes a country code, split it
    if (widget.phone.contains(' ')) {
      final parts = widget.phone.split(' ');
      _selectedCountryCode = parts[0];
      _phoneController.text = parts[1];
    }
  }

  Future<void> _updateUserData() async {
    if (_formKey.currentState?.validate() ?? false) {
      final user = FirebaseAuth.instance.currentUser;

      if (user != null) {
        await FirebaseFirestore.instance.collection('users').doc(user.uid).update({
          'phone': '$_selectedCountryCode ${_phoneController.text}',
          'weight': _weightController.text,
          'height': _heightController.text,
          'blood_type': _selectedBloodType,
          'insurance_provider': _insuranceProviderController.text,
          'place_of_birth': _placeOfBirthController.text,
        });

        Navigator.of(context).pop();
      }
    }
  }

  @override
  void dispose() {
    _phoneController.dispose();
    _weightController.dispose();
    _heightController.dispose();
    _bloodTypeController.dispose();
    _insuranceProviderController.dispose();
    _placeOfBirthController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Update Information'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              Row(
                children: [
                  DropdownButton<String>(
                    value: _selectedCountryCode,
                    onChanged: (String? newValue) {
                      setState(() {
                        _selectedCountryCode = newValue!;
                      });
                    },
                    items: <String>['+962', '+961', '+966']
                        .map<DropdownMenuItem<String>>((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(value),
                      );
                    }).toList(),
                  ),
                  Expanded(
                    child: TextFormField(
                      controller: _phoneController,
                      decoration: const InputDecoration(labelText: 'Phone'),
                      keyboardType: TextInputType.phone,
                    ),
                  ),
                ],
              ),
              TextFormField(
                controller: _weightController,
                decoration: const InputDecoration(labelText: 'Weight'),
                keyboardType: TextInputType.number,
              ),
              TextFormField(
                controller: _heightController,
                decoration: const InputDecoration(labelText: 'Height'),
                keyboardType: TextInputType.number,
              ),
              DropdownButtonFormField<String>(
                value: _selectedBloodType,
                decoration: const InputDecoration(labelText: 'Blood Type'),
                onChanged: (String? newValue) {
                  setState(() {
                    _selectedBloodType = newValue!;
                  });
                },
                items: <String>['O+', 'O-', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-']
                    .map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
              ),
              TextFormField(
                controller: _insuranceProviderController,
                decoration: const InputDecoration(labelText: 'Insurance Provider'),
              ),
              TextFormField(
                controller: _placeOfBirthController,
                decoration: const InputDecoration(labelText: 'Place of Birth'),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _updateUserData,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 40),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
                child: const Text(
                  'Save Information',
                  style: TextStyle(fontSize: 18),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
