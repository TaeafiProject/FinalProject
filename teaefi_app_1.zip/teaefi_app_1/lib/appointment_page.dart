import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class AppointmentPage extends StatefulWidget {
  final String doctorId;

  const AppointmentPage({Key? key, required this.doctorId}) : super(key: key);

  @override
  _AppointmentPageState createState() => _AppointmentPageState();
}

class _AppointmentPageState extends State<AppointmentPage> {
  DateTime _selectedDate = DateTime.now();
  String? _selectedTime;
  String? _selectedService;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  List<String> availableTimes = ['10:00 AM', '11:00 AM', '01:00 PM', '02:00 PM', '03:00 PM'];

  @override
  void initState() {
    super.initState();
    _fetchAvailableTimes();
  }

  Future<void> _fetchAvailableTimes() async {
    final appointmentsRef = FirebaseFirestore.instance.collection('appointments');
    final querySnapshot = await appointmentsRef
        .where('doctorId', isEqualTo: widget.doctorId)
        .where('date', isEqualTo: DateFormat('yyyy-MM-dd').format(_selectedDate))
        .get();

    List<String> bookedTimes = querySnapshot.docs.map((doc) => doc['time'] as String).toList();

    setState(() {
      availableTimes = availableTimes.where((time) => !bookedTimes.contains(time)).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Make Appointment'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Dates',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Container(
              height: 80,
              child: PageView.builder(
                itemCount: 30,
                itemBuilder: (context, index) {
                  DateTime date = DateTime.now().add(Duration(days: index));
                  return GestureDetector(
                    onTap: () {
                      setState(() {
                        _selectedDate = date;
                        _fetchAvailableTimes();
                      });
                    },
                    child: Container(
                      alignment: Alignment.center,
                      margin: EdgeInsets.symmetric(horizontal: 8.0),
                      decoration: BoxDecoration(
                        color: _selectedDate == date ? Colors.blue : Colors.grey,
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      child: Text(
                        DateFormat('d MMM').format(date),
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  );
                },
              ),
            ),
            SizedBox(height: 20),
            Text(
              'Choose Service',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            DropdownButtonFormField<String>(
              value: _selectedService,
              onChanged: (value) {
                setState(() {
                  _selectedService = value;
                });
              },
              items: ['Video Call Consultation', 'In-person Consultation']
                  .map((service) {
                return DropdownMenuItem(
                  value: service,
                  child: Text(service),
                );
              }).toList(),
            ),
            SizedBox(height: 20),
            Text(
              'Pick Time',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Wrap(
              spacing: 8.0,
              children: availableTimes.map((time) {
                return ChoiceChip(
                  label: Text(time),
                  selected: _selectedTime == time,
                  onSelected: (selected) {
                    setState(() {
                      _selectedTime = time;
                    });
                  },
                );
              }).toList(),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _selectedService != null && _selectedTime != null
                  ? _confirmAppointment
                  : null,
              child: Text('Confirm Appointment'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _confirmAppointment() async {
    try {
      final user = _auth.currentUser;
      if (user == null) return;

      final appointmentsRef = FirebaseFirestore.instance.collection('appointments');
      final querySnapshot = await appointmentsRef
          .where('doctorId', isEqualTo: widget.doctorId)
          .where('date', isEqualTo: DateFormat('yyyy-MM-dd').format(_selectedDate))
          .where('time', isEqualTo: _selectedTime)
          .get();

      if (querySnapshot.docs.isNotEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('The selected time slot is already booked.')),
        );
        return;
      }

      await appointmentsRef.add({
        'userId': user.uid,
        'doctorId': widget.doctorId,
        'service': _selectedService,
        'date': DateFormat('yyyy-MM-dd').format(_selectedDate),
        'time': _selectedTime,
        'createdAt': Timestamp.now(),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Appointment confirmed.')),
      );
    } catch (e) {
      print('Error confirming appointment: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error confirming appointment.')),
      );
    }
  }
}
