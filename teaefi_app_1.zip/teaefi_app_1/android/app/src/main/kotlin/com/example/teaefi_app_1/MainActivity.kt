package com.example.teaefi_app_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
